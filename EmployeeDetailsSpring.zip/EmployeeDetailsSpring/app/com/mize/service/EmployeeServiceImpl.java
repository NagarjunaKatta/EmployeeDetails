package com.mize.service;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mize.employee.Employee;
import com.mize.employeedao.EmployeeDAO;

@Component
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	EmployeeDAO employeeDAO;
	
	public EmployeeDAO getEmployeedao() {
		return employeeDAO;
	}
	public void setEmpdao(EmployeeDAO employeeDAO) {
		this.employeeDAO = employeeDAO;
	}
	@Override
	public List<Employee> getAllRecords() throws SQLException{
		
		return employeeDAO.getAllRecords();
	}
	@Override
	public Employee getEmployeeById(String id) throws SQLException {
		return employeeDAO.getEmployeeById(id);
	}
	
	@Override
	public boolean insertEmployee(Employee employee) throws SQLException {
		return employeeDAO.insertEmployee(employee);
	}
	
	@Override
	public boolean deleteEmployeeById(String id) throws SQLException {
		return employeeDAO.deleteEmployeeById(id);
	}
	
	@Override
	public boolean deleteAllEmployees() throws SQLException {
		return employeeDAO.deleteAllEmployees();
	}
	
	@Override
	public int updateEmployee(Employee employee) throws SQLException {
		
		return employeeDAO.updateEmployee(employee);
	}
}
