package com.mize.employeedao;

import java.sql.SQLException;
import java.util.List;

import com.mize.employee.Employee;

public interface EmployeeDAO {

	public List<Employee> getAllRecords() throws SQLException;

	public Employee getEmployeeById(String id) throws SQLException;

	public boolean insertEmployee(Employee employee) throws SQLException;
	
	public boolean deleteEmployeeById(String id) throws SQLException;
	
	public boolean deleteAllEmployees() throws SQLException;

	public int updateEmployee(Employee employee) throws SQLException;
}