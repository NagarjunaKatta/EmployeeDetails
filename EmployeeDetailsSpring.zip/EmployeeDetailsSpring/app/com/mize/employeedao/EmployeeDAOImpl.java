package com.mize.employeedao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.mize.employee.Employee;

@Component
public class EmployeeDAOImpl implements EmployeeDAO , RowMapper<Employee> {
	
	@Autowired
	private DataSource dataSource;
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}
	
	@Override
	public List<Employee> getAllRecords() {
		play.Logger.info("Entered getAllRecords()");
		String AllRecordsQuery="select * from employee";
		List<Employee> employee=(List<Employee>) jdbcTemplate.query(AllRecordsQuery,this);
		return employee;
	}
	
	@Override
	public Employee getEmployeeById(String id) {
		String getEmployeeByIdQuery="select * from employee where id=?";
		Employee emp=jdbcTemplate.queryForObject(getEmployeeByIdQuery, new Object[]{id},this);
		return emp;
	}
	
	@Override
	public boolean insertEmployee(Employee employee){
		boolean status=false;
		String InsertQuery="insert into employee values(?,?,?,?)";
		jdbcTemplate.update(InsertQuery, new Object[]{ employee.getId(),employee.getName(),employee.getDepartment(),employee.getSalary()});
		status=true;
		return status;
	}
	
	@Override
	public boolean deleteEmployeeById(String id){
		boolean status=false;
		String deleteByIdQuery="delete from employee where id=?";
		jdbcTemplate.update(deleteByIdQuery,new Object[]{id});
		status=true;
		return status;
	}
	
	@Override
	public boolean deleteAllEmployees(){
		String deleteQuery="delete from employee";
		jdbcTemplate.update(deleteQuery);
		return true;
	}
	
	@Override
	public int updateEmployee(Employee employee){
		String updateQuery="update employee set name=?,department=?,salary=? where id=?";
		int count=jdbcTemplate.update(updateQuery, new Object[]{ employee.getName(),employee.getDepartment(),employee.getSalary(),employee.getId()});
		return count;
	}
	
	@Override
	public Employee mapRow(ResultSet arg, int arg1) throws SQLException{
		Employee employee=new Employee();
		employee.setId(arg.getLong("id"));
		employee.setName(arg.getString("name"));
		employee.setDepartment(arg.getString("department"));
		employee.setSalary(arg.getDouble("salary"));
		return employee;
	}
}
